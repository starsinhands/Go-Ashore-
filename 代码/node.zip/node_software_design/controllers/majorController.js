const { getByMajor } = require("../services/majorService");

const MajorController = {
  async getByMajors(ctx, next) {
    const { school, major, learnForm } = ctx.request.query;
    try {
      const res = await getByMajor(school, major, learnForm);
      console.log("controller res:", res);
      ctx.body = {
        code: 200,
        msg: "操作成功",
        data: res,
      };
    } catch (error) {
      console.log(error);
      ctx.body = {
        code: 500,
        msg: "服务器错误",
        data: "",
      };
    }
  },
  // async getBySubjects(ctx, next) {
  //   const { subjectNum } = ctx.request.query;
  //   try {
  //     const res = await getBySubject(subjectNum);
  //     console.log("controller res:", res);
  //     ctx.body = {
  //       code: 200,
  //       msg: "操作成功",
  //       data: res,
  //     };
  //   } catch (error) {
  //     console.log(error);
  //     ctx.body = {
  //       code: 500,
  //       msg: "服务器错误",
  //       data: "",
  //     };
  //   }
  // },
};

module.exports = MajorController;
