const { reguser, login } = require("../services/userService");

const UserController = {
  async doRegUser(ctx, next) {
    try {
      const res = await reguser(ctx.request.body);
      console.log("controller res:", res);
      if (res == "密码必须同时包含至少一个字母和一个数字") {
        ctx.body = {
          code: 400,
          msg: "操作失败",
          result: res,
        };
      }
      if (res == "账号已经存在，请使用其他账号注册") {
        ctx.body = {
          code: 400,
          msg: "操作失败",
          result: res,
        };
      }
      if (res == "号码格式错误") {
        ctx.body = {
          code: 400,
          msg: "操作失败",
          result: res,
        };
      }
      if (res == "用户注册成功") {
        ctx.body = {
          code: 200,
          msg: "操作成功",
          result: res,
        };
      }
    } catch (error) {
      console.log(error);
      ctx.body = {
        code: 500,
        msg: "服务器错误",
        result: "",
      };
    }
  },
  async doLogin(ctx, next) {
    try {
      const res = await login(ctx.request.body);
      console.log("controller res:", res);
      if (res == "账号或密码错误") {
        ctx.body = {
          code: 400,
          msg: "账号或密码错误",
        };
        return;
      }
      if (res == "用户不存在") {
        ctx.body = {
          code: 400,
          msg: "用户不存在",
        };
        return;
      }
      // if (res == "用户名和电话号码不匹配") {
      //   ctx.body = {
      //     code: 400,
      //     msg: "用户名和电话号码不匹配",
      //   };
      //   return;
      // }
      ctx.body = {
        code: 200,
        msg: "登录成功",
        result: res,
      };
    } catch (error) {
      console.log(error);
      ctx.body = {
        code: 500,
        msg: "服务器错误",
      };
    }
  },
};

module.exports = UserController;
