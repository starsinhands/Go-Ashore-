const {
  getSchoolsByProvince,
  getSchools,
  getSchoolsByTags
} = require("../services/schoolService");

const SchoolController = {
  async getAllSchools(ctx, next) {
    try {
      const res = await getSchools();
      console.log("controller res:", res);
      ctx.body = {
        code: 200,
        msg: "操作成功",
        data: res,
      };
    } catch (error) {
      console.log(error);
      ctx.body = {
        code: 500,
        msg: "服务器错误",
        data: "",
      };
    }
  },
  async getByProvince(ctx, next) {
    const { location } = ctx.request.query;
    try {
      console.log("location:", location);
      const res = await getSchoolsByProvince(location);
      // res.json({ schools });
      console.log("controller res:", res);
      ctx.body = {
        code: 200,
        msg: "操作成功",
        data: res,
      };
    } catch (error) {
      // res.status(500).json({ error: error.message });
      console.log(error);
      ctx.body = {
        code: 500,
        msg: "服务器错误",
        data: "",
      };
    }
  },
  async getsubject(ctx, next) {
    const { is_985,is_211,is_firClassU,is_firClassS,is_else } = ctx.request.query;
    try {
      // console.log("location:", location);
      const is_firclassU = is_firClassU
      const is_firclassS = is_firClassS
      const res = await getSchoolsByTags(is_985,is_211,is_firclassU,is_firclassS,is_else);
      console.log({is_985,is_211,is_firclassU,is_firclassS,is_else});
      // res.json({ schools });
      console.log("controller res:", res);
      ctx.body = {
        code: 200,
        msg: "操作成功",
        data: res,
      };
    } catch (error) {
      // res.status(500).json({ error: error.message });
      console.log(error);
      ctx.body = {
        code: 500,
        msg: "服务器错误",
        data: "",
      };
    }
  }
};

module.exports = SchoolController;
