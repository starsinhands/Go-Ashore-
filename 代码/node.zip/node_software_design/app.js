// 导入 express
const express = require("express");
// 创建服务器的实例对象
const app = express();
const joi = require("joi");

// 导入并配置 cors 中间件
const cors = require("cors");
app.use(cors());

// 对外共享静态资源
app.use('/assert', express.static('./assert'))
// app.use('/assert/picture', express.static('./assert/picture_compress20'))

// 配置解析表单数据的中间件，注意：这个中间件，只能解析 application/x-www-form-urlencoded 格式的表单数据
app.use(express.urlencoded({ extended: false }));

// 一定要在路由之前，封装 res.cc 函数
app.use((req, res, next) => {
  // status 默认值为 1，表示失败的情况
  // err 的值，可能是一个错误对象，也可能是一个错误的描述字符串
  res.cc = function (err, code = 500) {
    // 若未指定出错代码，则默认500
    res.send({
      code,
      msg: err instanceof Error ? err.message : err,
    });
  };
  next(); // 不要忘记写 next()
});

// 一定要在路由之前配置解析 Token 的中间件
const { expressjwt: expressJWT } = require("express-jwt");
const config = require("./config");

app.use(
  expressJWT({
    secret: config.jwtSecretKey,
    algorithms: ["HS256"],
  }).unless({ path: [/^\/user/, /^\/assert/] })
); // 不进行身份验证的路径

// 导入并使用用户信息的路由模块
const user = require("./router/user");
app.use("/user", user);
const schoolRoutes = require("./router/schoolRoutes");
app.use("/user", schoolRoutes);

// 定义错误级别的中间件
app.use((err, req, res, next) => {
  // 验证失败导致的错误
  if (err instanceof joi.ValidationError) return res.cc(err);
  // 身份认证失败后的错误
  if (err.name === "UnauthorizedError") return res.cc("身份认证失败！", 401);
  // 未知的错误
  res.cc(err);
});

// 服务器端配置
// 本地端口为 40400，外网可以以 http://api.tuanwei.hacon.top:80
// 有cors中间件，不会存在跨域问题
const { APP_PORT } = require("./database/config.default");
app.listen(APP_PORT, () => {
  console.log(`api server running at http://127.0.0.1:${APP_PORT}`);
});

// 除此之外还要更改数据库
