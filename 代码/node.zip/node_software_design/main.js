const { APP_PORT } = require("./database/config.default");
const app = require("./app/index");

app.listen(APP_PORT, () => {
  console.log(`api server running at http://127.0.0.1:${APP_PORT}`);
});
