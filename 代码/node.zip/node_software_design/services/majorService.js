const Major = require("../models/majorModel");

const MajorService = {
  // 根据专业获取院校信息
  async getByMajor(school, major, learnForm) {
    try {
      const res = await Major.findAll({
        where: { school: school, major: major, learnForm: learnForm },
      });
      console.log("service res:", res);
      return res;
    } catch (error) {
      // return error;
      console.log("根据专业获取院校信息失败！");
      // throw new Error("Failed to retrieve schools by province");
    }
  },

  // 根据考试科目获取院校信息
  // async getBySubject(school, major, learnForm) {
  //   try {
  //     const res = await Major.findAll({
  //       where: { school: school, major: major, lLearnForm: learnForm },
  //     });
  //     console.log("service res:", res);
  //     return res;
  //   } catch (error) {
  //     // return error;
  //     console.log("根据考试科目获取院校信息失败！");
  //     // throw new Error("Failed to retrieve schools by province");
  //   }
  // },
};

module.exports = MajorService;
