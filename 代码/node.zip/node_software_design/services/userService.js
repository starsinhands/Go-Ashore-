const UserInfo = require("../models/userModel");

const UserService = {
  // 用户注册
  // async reguser(body) {
  //   try {
  //     const { username, password } = body;
  //     console.log("reg username:", username);
  //     console.log("reg password:", password);
  //     //检查用户名是否已存在
  //     const existingUser = await UserInfo.findOne({ where: { username } });
  //     if (existingUser) {
  //       return "用户名已经存在，请使用其他用户名注册";
  //     }
  //     //检查密码复杂度
  //     const passwordRegex = /^(?=.*[a-zA-Z])(?=.*[0-9])/; //密码需要包含至少一个字母和一个数字
  //     if (!passwordRegex.test(password)) {
  //       return "密码必须同时包含至少一个字母和一个数字";
  //     }
  //     //创建新用户
  //     const newUser = await UserInfo.create({
  //       username,
  //       password,
  //     });
  //     console.log("new user:", newUser);
  //     return "用户注册成功";
  //   } catch (error) {
  //     console.log("error:", error);
  //     throw error;
  //   }
  // },

  // 用户注册
  async reguser(body) {
    try {
      let username, password, phone;
      let isExist;
      console.log("body:", body);
      if (body.username) {
        username = body.username;
        password = body.password;
        phone = null;
        isExist = await UserInfo.findOne({ where: { username: username } });
      } else {
        phone = body.phone;
        password = body.password;
        username = null;
        isExist = await UserInfo.findOne({ where: { phone: phone } });
      }
      console.log("reg username:", username);
      console.log("reg password:", password);
      console.log("reg phone:", phone);

      // 检查用户名或号码是否已存在
      // const existingUser = await UserInfo.findOne({
      //   $or: [{ username: username }, { phone: phone }],
      // });
      if (isExist) {
        return "账号已经存在，请使用其他账号注册";
      }

      // 检查密码复杂度
      const passwordRegex = /^(?=.*[a-zA-Z])(?=.*[0-9])/; // 密码需要包含至少一个字母和一个数字
      if (!passwordRegex.test(password)) {
        return "密码必须同时包含至少一个字母和一个数字";
      }

      // 检查号码格式是否符合要求
      if (phone && !/^\d{11}$/.test(phone)) {
        return "号码格式错误";
      }

      // 创建新用户
      const newUser = await UserInfo.create({
        username,
        password,
        phone,
      });
      console.log("new user:", newUser);
      return "用户注册成功";
    } catch (error) {
      console.log("error:", error.message);
      throw error;
    }
  },
  // 用户登录
  async login(body) {
    try {
      let username, password, phone;
      if (body.username) {
        username = body.username;
        password = body.password;
      } else {
        phone = body.phone;
        password = body.password;
      }
      console.log("login service:", body);

      const user = await UserInfo.findOne({
        where: { username: username }
      });

      if (!user) {
        console.log("用户不存在");
        return "用户不存在";
      }

      const isLoginByUsername = user.username == username;
      const isLoginByPhone = user.phone == phone;

      console.log("isLoginByUsername", isLoginByUsername);
      console.log("isLoginByPhone", isLoginByPhone);

      // if (
      //   user.username != username ||
      //   user.phone != phone ||
      //   user.password != password
      // ) {
      //   console.log("账号或密码错误");
      //   return "账号或密码错误";
      // }
      // console.log("11111111")
      console.log(user.dataValues)
      if (username && user.dataValues.username != username) {
        console.log("用户名不匹配");
        return "账号或密码错误";
      }

      if (phone && user.dataValues.phone != phone) {
        console.log("电话号码不匹配");
        return "账号或密码错误";
      }

      if (user.dataValues.password != password) {
        console.log("密码错误");
        return "账号或密码错误";
      }

      return user;
    } catch (error) {
      console.log("error:", error.message);
      throw error;
    }
  },
};
module.exports = UserService;
