const School = require("../models/schoolModel");

const SchoolService = {
  async getSchools() {
    try {
      const res = await School.findAll();
      console.log("service res:", res);
      return res;
    } catch (error) {
      console.log("获取学校信息失败！");
    }
  },
  async getSchoolsByProvince(location) {
    try {
      const res = await School.findAll({ where: { location: location } });
      console.log("service res:", res);
      return res;
    } catch (error) {
      // return error;
      console.log("获取学校信息失败！");
      // throw new Error("Failed to retrieve schools by province");
    }
  },
  async getSchoolsByTags(is_985, is_211, is_firclassU, is_firclassS, is_else) {
    if (is_985) {
      try {
        const res = await School.findAll({ where: { is_985: is_985 } });
        // console.log("service res:", res);
        return res;
      } catch (error) {
        // return error;
        console.log("获取学校信息失败！");
        // throw new Error("Failed to retrieve schools by province");
      }
    } else if (is_211) {
      try {
        const res = await School.findAll({ where: { is_211: is_211 } });
        // console.log("service res:", res);
        return res;
      } catch (error) {
        // return error;
        console.log("获取学校信息失败！");
        // throw new Error("Failed to retrieve schools by province");
      }
    } else if (is_firclassU) {
      try {
        const res = await School.findAll({ where: { is_firclassU: is_firclassU } });
        // console.log("service res:", res);
        return res;
      } catch (error) {
        // return error;
        console.log("获取学校信息失败！");
        // throw new Error("Failed to retrieve schools by province");
      }
    } else if (is_firclassS) {
      try {
        const res = await School.findAll({ where: { is_firclassS: is_firclassS } });
        // console.log("service res:", res);
        return res;
      } catch (error) {
        // return error;
        console.log("获取学校信息失败！");
        // throw new Error("Failed to retrieve schools by province");
      }
    } else {
      try {
        const res = await School.findAll({ where: { is_else: is_else } });
        // console.log("service res:", res);
        return res;
      } catch (error) {
        // return error;
        console.log("获取学校信息失败！");
        // throw new Error("Failed to retrieve schools by province");
      }
    }
  },
};

module.exports = SchoolService;
