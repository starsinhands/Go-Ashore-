// const express = require("express");
const Router = require("koa-router");
const {
  getByProvince,
  getAllSchools,
  getsubject,
} = require("../controllers/schoolController");
// const router = express.Router();
const router = new Router();

router.get("/user/school", getByProvince); // 根据地区获取学校信息
router.get("/user/allschool", getAllSchools); // 获取全部学校信息 无需传参
router.get("/user/subject", getsubject); // 获取全部学校信息 无需传参

module.exports = router;
