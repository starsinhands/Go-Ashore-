// const express = require("express");
const Router = require("koa-router");
const {
  getByMajors,
  getBySubjects,
} = require("../controllers/majorController");
// const router = express.Router();
const router = new Router();

router.get("/user/major", getByMajors);
// router.get("/subject", getBySubjects);

module.exports = router;
