const db = require("../database/dbConfig");
const { DataTypes } = require("sequelize");
const sequelize = require("../database/db");

const Major = sequelize.define(
  "Major",
  {
    school: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "院校名称",
    },
    major: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "专业名称",
    },
    resDirection: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "研究方向",
    },
    institute: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "院系所",
    },
    admScore: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "复试分数",
    },
    enrPlan: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "招生计划",
    },
    examForm: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "考试方式",
    },
    learnForm: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "学习方式",
    },
    examScope: {
      type: DataTypes.TEXT,
      comment: "考试范围",
    },
    remark: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: "备注",
    },
  },
  { timestamps: false, freezeTableName: true }
);
// 同步模型与数据库
// sequelize
//   .sync()
//   .then(() => {
//     console.log("模型与数据库同步成功");
//   })
//   .catch((error) => {
//     console.error("模型与数据库同步失败:", error);
//   });
module.exports = Major;
