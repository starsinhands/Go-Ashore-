const db = require("../database/dbConfig");
const { DataTypes } = require("sequelize");
const sequelize = require("../database/db");

const School = sequelize.define(
  "School",
  {
    schName: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "院校名称",
    },
    location: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "地区",
    },
    subjection: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "隶属单位",
    },
    is_985: {
      type: DataTypes.TINYINT,
      defaultValue: 0,
      comment: "是否为985",
    },
    is_211: {
      type: DataTypes.TINYINT,
      defaultValue: 0,
      comment: "是否为211",
    },
    is_firClassU: {
      type: DataTypes.TINYINT,
      defaultValue: 0,
      comment: "是否为一流大学",
    },
    is_firClassS: {
      type: DataTypes.TINYINT,
      defaultValue: 0,
      comment: "是否为一流学科",
    },
    assessmentCS: {
      type: DataTypes.STRING,
      defaultValue: null,
      comment: "计算机学科评估",
    },
    assessmentSE: {
      type: DataTypes.STRING,
      defaultValue: null,
      comment: "软件学科评估",
    },
    // 其他字段依此类推
  },
  { timestamps: false, freezeTableName: true }
);

module.exports = School;
