const { DataTypes } = require("sequelize");
const sequelize = require("../database/db");

const UserInfo = sequelize.define(
  "user_info",
  {
    username: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: "用户名称",
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "密码",
    },
    delete: {
      type: DataTypes.INTEGER,
      // allowNull: false,
      defaultValue: 0,
      comment: "软删除标记",
    },
    email: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: "邮箱",
    },
    picture: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: "头像",
    },
    phone: {
      type: DataTypes.BIGINT,
      allowNull: true,
      comment: "电话号码",
    },
  },
  { timestamps: false, freezeTableName: true }
);

// 同步模型与数据库
// sequelize
//   .sync()
//   .then(() => {
//     console.log("模型与数据库同步成功");
//   })
//   .catch((error) => {
//     console.error("模型与数据库同步失败:", error);
//   });
module.exports = UserInfo;
