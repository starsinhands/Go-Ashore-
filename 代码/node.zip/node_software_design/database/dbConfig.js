const mysql = require("mysql2");

// 本地数据库
const db = mysql.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "12345678",
  database: "software_design",
});

// // 服务器端数据库
// const db = mysql.createPool({
//   host: '127.0.0.1',
//   user: 'root',
//   password: 'd856fcc6c9a9f282',
//   database: 'software_design',
// })

module.exports = db;
