let config = {
  APP_PORT: 40400,
  MYSQL_HOST: "localhost",
  MYSQL_PORT: 3306,
  MYSQL_USER: "root",
  MYSQL_PWD: "123123",
  MYSQL_DB: "software_design",
  MYSQL_TYPE: "mysql",
  // SALT: 10, //密码加密 加盐 10 次,
  // JWTSECRET: "ztz",
  // APPID: "wx6108bf2c6ba79156",
  // SECRET: "13a41762fa0d21dec0aaeb729040352a",
  // APIKEY: "078b65ada7136beb6a432a3499b71f43",
};

module.exports = config;
