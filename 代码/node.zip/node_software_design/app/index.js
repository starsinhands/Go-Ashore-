const Koa = require("koa");

const errorHandle = require("../database/error.config");

const { koaBody } = require("koa-body");

const router = require("../router");

const sslify = require("koa-sslify").default;

const statics = require("koa-static");

// const bodyParse = require('koa-bodyparser')

const cors = require("koa2-cors");

const path = require("path");

const app = new Koa();

// app.use(sslify()) https才开启

app.use(
  koaBody({
    multipart: true,
    formidable: {
      // 上传目录
      // uploadDir: path.join(__dirname, '../static'),
      // 保留文件扩展名
      keepExtensions: true,
      maxFieldsSize: 200 * 1024 * 1024,
    },
  })
);

app.use(statics(path.join(__dirname , "../static")));

// app.use(bodyParse())   // 建议使用cor-body
app.use(cors());

// start
// 一定要在路由之前配置解析 Token 的中间件
const config = require("../config");
const joi = require("joi");
const jwt = require("jsonwebtoken");
const koaJwt = require("koa-jwt");
app.use(
  koaJwt({ secret: config.jwtSecretKey, algorithms: ["HS256"] }).unless({
    path: [/^\/user/],
  })
);
// end

app.use(router.routes());
app.use(router.allowedMethods());

app.on("error", errorHandle);

module.exports = app;
