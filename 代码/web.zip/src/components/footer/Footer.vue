<template>
  <div class="footer">
    <div style="padding: 10px 50px">
      <a-row :gutter="gutter">
        <a-col :span="span1">
          <a-card title="开源与自链接" :bordered="false" class="footer-info">
            <!-- <p><a-icon type="github" theme="filled" /><a href=""> GitHub</a></p>
            <p><a-icon type="github" theme="filled" /><a href=""> 院校</a></p> -->
            <ul>
              <!-- <li><a href=""> GitHub</a></li> -->
              <li><a href="#/schools"> 院校</a></li>
              <li><a href="#/majors"> 专业</a></li>
              <li><a href="#/subjects"> 科目</a></li>
              <li><a href="#/materials"> 资料</a></li>
            </ul>
          </a-card>
        </a-col>
        <a-col :span="span2">
          <a-card title="友情链接" :bordered="false">
            <ul>
              <!-- <li v-for="item in links" :key="item.id">
                <a :href="item.url" target="blank">{{ item.webTitle }}</a>
              </li> -->
              <li><a href="https://yz.chsi.com.cn/"> 研招网</a></li>
              <li><a href="https://www.kaoyan.com/"> 考研帮</a></li>
              <li><a href="http://www.okaoyan.com/"> 考研派</a></li>
            </ul>
          </a-card>
        </a-col>
        <a-col :span="span3">
          <a-card title="关于「上岸吧」" :bordered="false">
            <p>
              「上岸吧」是一款用于计算机考研信息查询的网站系统，致力于为计算机类专业考生确定目标院校时期提供信息查询服务。
            </p>
          </a-card>
        </a-col>
      </a-row>
    </div>
    <!--版权信息-->
    <div class="copy">
      <div class="container">
        <p style="height: 10px;line-height: 10px;margin-bottom: 20px;">
          Copyright &copy; 2024 /上岸吧/
        </p>
        <p style="height: 10px;line-height: 10px;margin-bottom: 20px;">
          -- 上岸吧全程定制你的考研之旅 --
        </p>
        <p style="height: 10px;line-height: 10px;margin-bottom: 20px;">
          -- 专注考研咨询10年，30万考研学子的黄埔军校 --
        </p>
        <div class="clearfix"></div>
      </div>
    </div>
  </div>
</template>

<script>
// import axios from 'axios'
export default {
  name: 'FooterComp',
  data() {
    return {
      links: [],
      // 响应式
      isLargeScreen: true,
      isMediunScreen: false,
      isSmallScreen: false,
      gutter: 150,
      span1: 8,
      span2: 8,
      span3: 8
    }
  },
  mounted() {
    // this.getLinks()
    this.getWindowResize()
    window.addEventListener('resize', this.getWindowResize)
  },
  methods: {
    // getLinks() {
    //   const url = 'http://127.0.0.1:8000/api/links/'
    //   axios
    //     .get(url)
    //     .then((res) => {
    //       this.links = res.data
    //       // console.log(res.data)
    //     })
    //     .catch((e) => {
    //       alert(e)
    //     })
    // }
    getWindowResize() {
      this.screenWidth = document.body.clientWidth
      this.screeHeight = document.body.clientHeight
      // 做响应式
      if (this.screenWidth >= 992) {
        this.isLargeScreen = true
        this.isMediunScreen = false
        this.isSmallScreen = false
        this.gutter = 150
        this.span1 = 8
        this.span2 = 8
        this.span3 = 8
      } else if (this.screenWidth >= 768) {
        this.isLargeScreen = false
        this.isMediunScreen = true
        this.isSmallScreen = false
        this.gutter = 50
        this.span1 = 8
        this.span2 = 8
        this.span3 = 8
      } else {
        this.isLargeScreen = false
        this.isMediunScreen = false
        this.isSmallScreen = true
        this.gutter = 20
        this.span1 = 12
        this.span2 = 12
        this.span3 = 24
      }
    }
  }
}
</script>

<style>
.footer {
  margin: 20px 20px 0 20px;
}

@media (min-width: 768px) and (max-width: 992px) {
  .footer {
    margin: 20px 20px 0 20px;
  }
}
</style>
