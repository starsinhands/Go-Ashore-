<template>
  <div class="main">
    <div class="logo" v-if="this.isMediunScreen">
      <router-link to="/" @click.native="changeNavId(1)">
        <img src="@/assets/logo.png" alt="logo" style="height: 80%;" /></router-link>
    </div>
    <!-- 大屏幕 -->
    <div class="button-left" v-if="this.isLargeScreen">
      <div class="logo">
        <router-link to="/" @click.native="changeNavId(1)"><img src="@/assets/logo.png" alt="logo"
            style="height: 80%;" /></router-link>
      </div>
      <router-link @click.native="changeNavId(2)" active-class="active" tag="button"
        to="/video"><span>主页</span></router-link>
      <router-link @click.native="changeNavId(3)" active-class="active" tag="button"
        to="/schools"><span>学校</span></router-link>
      <router-link @click.native="changeNavId(4)" active-class="active" tag="button"
        to="/majors"><span>专业</span></router-link>
      <router-link @click.native="changeNavId(5)" active-class="active" tag="button"
        to="/subjects"><span>科目</span></router-link>
      <router-link @click.native="changeNavId(6)" active-class="active" tag="button"
        to="/materials"><span>资料</span></router-link>
      <router-link @click.native="changeNavId(7)" active-class="active" tag="button"
        to="/score"><span>成绩</span></router-link>
      <router-link @click.native="changeNavId(8)" active-class="active" tag="button"
        to="/post"><span>发帖</span></router-link>
      <router-link @click.native="changeNavId(9)" active-class="active" tag="button"
        to="/adjustment"><span>调剂</span></router-link>
    </div>
    <!-- 中等屏幕 -->
    <div class="medium-button-left" v-if="this.isMediunScreen">
      <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="handleSelect">
        <el-menu-item index="0">
          <router-link @click.native="changeNavId(2)" to="/video">
            主页
          </router-link>
        </el-menu-item>
        <el-submenu index="1">
          <template slot="title">报考篇</template>
          <router-link @click.native="changeNavId(3)" to="/schools">
            <el-menu-item index="1-1">学校</el-menu-item>
          </router-link>
          <router-link @click.native="changeNavId(4)" to="/majors">
            <el-menu-item index="1-2">专业</el-menu-item>
          </router-link>
          <router-link @click.native="changeNavId(5)" to="/subjects">
            <el-menu-item index="1-2">科目</el-menu-item>
          </router-link>
        </el-submenu>
        <el-submenu index="2">
          <template slot="title">备考篇</template>
          <router-link @click.native="changeNavId(6)" to="/materials">
            <el-menu-item index="2-1">资料</el-menu-item>
          </router-link>
        </el-submenu>
        <el-submenu index="3">
          <template slot="title">录取篇</template>
          <router-link @click.native="changeNavId(7)" to="/score">
            <el-menu-item index="3-1">成绩</el-menu-item>
          </router-link>
          <router-link @click.native="changeNavId(8)" to="/post">
            <el-menu-item index="3-2">发帖</el-menu-item>
          </router-link>
          <router-link @click.native="changeNavId(9)" to="/adjustment">
            <el-menu-item index="3-3">调剂</el-menu-item>
          </router-link>

        </el-submenu>
      </el-menu>
    </div>
    <!-- 小屏幕 -->
    <div class="medium-button-left" v-if="this.isSmallScreen">
      <el-menu :default-active="0" class="el-menu-demo" mode="horizontal" @select="handleSelect">
        <el-submenu index="1">
          <template slot="title">菜单</template>
          <router-link @click.native="changeNavId(2)" to="/video">
            <el-menu-item index="0-1">主页</el-menu-item>
          </router-link>
          <el-submenu index="1-1">
            <template slot="title">报考篇</template>
            <router-link @click.native="changeNavId(3)" to="/schools">
              <el-menu-item index="1-1-1">学校</el-menu-item>
            </router-link>
            <router-link @click.native="changeNavId(4)" to="/majors">
              <el-menu-item index="1-1-2">专业</el-menu-item>
            </router-link>
            <router-link @click.native="changeNavId(5)" to="/subjects">
              <el-menu-item index="1-1-2">科目</el-menu-item>
            </router-link>
          </el-submenu>
          <el-submenu index="1-2">
            <template slot="title">备考篇</template>
            <router-link @click.native="changeNavId(6)" to="/materials">
              <el-menu-item index="1-2-1">资料</el-menu-item>
            </router-link>
          </el-submenu>
          <el-submenu index="1-3">
            <template slot="title">录取篇</template>
            <router-link @click.native="changeNavId(7)" to="/score">
              <el-menu-item index="1-3-1">成绩</el-menu-item>
            </router-link>
            <router-link @click.native="changeNavId(8)" to="/post">
              <el-menu-item index="1-3-2">发帖</el-menu-item>
            </router-link>
            <router-link @click.native="changeNavId(9)" to="/adjustment">
              <el-menu-item index="1-3-3">调剂</el-menu-item>
            </router-link>
          </el-submenu>
        </el-submenu>
      </el-menu>
    </div>
    <!-- 注册/登录按钮及表单 -->
    <Registe-and-login />
    <!-- 用户卡片按钮及表单 -->
    <User-Card />
  </div>
</template>

<script>
import UserCard from '@/components/header/UserCard/UserCard.vue'
import RegisteAndLogin from '@/components/header/RegisteAndLogin/RegisteAndLogin.vue'
export default {
  name: 'NavbarComp',
  components: { RegisteAndLogin, UserCard },
  data() {
    return {
      screenWidth: document.body.clientWidth, // 屏幕宽
      screeHeight: document.body.clientHeight, // 屏幕高
      // 响应式
      isLargeScreen: true,
      isMediunScreen: false,
      isSmallScreen: false,
      // 中等屏幕菜单栏激活
      activeIndex: '1'
    }
  },
  mounted() {
    this.checkLocalStorage()
    this.getWindowResize()
    window.addEventListener('resize', this.getWindowResize)
  },
  methods: {
    // 改变vuex 中Navbar的id
    changeNavId(id) {
      this.$store.commit('ChangeNavId', id)
    },
    checkLocalStorage() {
      if (localStorage.getItem('user_id')) {
        this.$store.commit('ChangeLoginState', true)
      }
    },
    getWindowResize() {
      this.screenWidth = document.body.clientWidth
      this.screeHeight = document.body.clientHeight
      // 做响应式
      if (this.screenWidth >= 992) {
        this.isLargeScreen = true
        this.isMediunScreen = false
        this.isSmallScreen = false
      } else if (this.screenWidth >= 768) {
        this.isLargeScreen = false
        this.isMediunScreen = true
        this.isSmallScreen = false
      } else {
        this.isLargeScreen = false
        this.isMediunScreen = false
        this.isSmallScreen = true
      }
    }
  }
}
</script>

<style scoped>
.main {
  width: 100%;
  height: 100%;
  background-color: white;
}

.logo {
  height: 70px;
  float: left;
}

.logo>img {
  height: 100%;
}

.button-left {
  float: left;
  margin-left: 20px;
}

.medium-button-left {
  float: left;
  margin-left: 20px;
}

.el-dropdown-link {
  cursor: pointer;
  color: #409EFF;
}

.el-icon-arrow-down {
  font-size: 12px;
}

.button-left button {
  display: inline-block;
  background-color: #ffffff;
  border-radius: 20px;
  border: 1px solid #dcdfe6;
  color: #000000;
  text-align: center;
  font-size: 14px;
  width: 76px;
  height: 40px;
  line-height: 40px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button-left button span {
  text-align: center;
  height: 100%;
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button-left button:hover {
  color: #409eff;
  border-color: #a5cefa;
  background-color: #ecf5ff;
}

.button-left button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button-left button:hover span {
  padding-right: 15px;
}

.button-left button:hover span:after {
  opacity: 1;
  right: 0;
}

.active {
  color: #409eff !important;
  border-color: #4591e4 !important;
  background-color: #ecf5ff !important;
}
</style>
