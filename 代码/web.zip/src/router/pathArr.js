export default ['', '/home']
