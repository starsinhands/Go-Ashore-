import Vue from 'vue'
import VueRouter from 'vue-router'
// 导入需要前置守卫拦截的 hash 地址
import pathArr from '@/router/pathArr.js'

Vue.use(VueRouter)

// 创建router实例对象，去管理一组一组的路由规则
const router = new VueRouter({
  routes: [
    {
      path: '/',
      // component: Index
      component: resolve => require(['@/pages/Index'], resolve)
    },
    {
      path: '/video',
      // component: Video
      component: resolve => require(['@/pages/Video'], resolve)
    },
    {
      path: '/schools',
      // component: Schools,
      component: resolve => require(['@/pages/Schools'], resolve)
    },
    {
      path: '/majors',
      // component: Majors
      component: resolve => require(['@/pages/Majors'], resolve)
    },
    {
      path: '/subjects',
      // component: Subjects
      component: resolve => require(['@/pages/Subjects'], resolve)
    },
    {
      path: '/materials',
      // component: Materials
      component: resolve => require(['@/pages/Materials'], resolve)
    },
    {
      path: '/score',
      // component: Score
      component: resolve => require(['@/pages/Score'], resolve)
    },
    {
      path: '/post',
      // component: Post
      component: resolve => require(['@/pages/Post'], resolve)
    },
    {
      path: '/adjustment',
      // component: Adjustment
      component: resolve => require(['@/pages/Adjustment'], resolve)
    },
    {
      path: '/userProfile',
      // component: UserProfile
      component: resolve => require(['@/pages/UserProfile'], resolve)
    }

  ]
})

router.beforeEach(function(to, from, next) {
  // 如果没有 token，则强制跳转到 /login 登录页
  // console.log(router)
  if (pathArr.indexOf(to.path) !== -1) {
    // 要访问后台主页，需要判断是否有 token
    const token = localStorage.getItem('token')
    if (token) {
      next()
    } else {
      // 没有登录，强制跳转到登录页
      next('/login')
    }
  } else {
    next()
  }
})

const VueRouterPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(to) {
  return VueRouterPush.call(this, to).catch(err => err)
}

export default router
