// 导出 API 相关接口

// const userServe = 'http://127.0.0.1:40400' // 本地接口
const userServe = 'http://47.115.211.207:40400' // 服务器接口

// 服务器的地址
// 使用线上的地址
// const userServe = 'http://218.192.110.172:7030'

export default {
  // 静态文件接口
  assets: userServe,
  // 注册接口
  userSignUp: userServe + '/user/reguser',
  // 登录接口
  userLogin: userServe + '/user/login',
  // 判断登录状态接口
  userName: userServe + '/user/username',
  // 意见反馈
  feedback: userServe + '/feedback',
  // 获取全部学校信息
  allschool: userServe + '/user/allschool',
  // 根据地区获取学校信息
  localSchool: userServe + '/user/school',
  // 获取专业信息
  major: userServe + '/user/major',
  // 根据科目和院校标签获取院校信息
  subject: userServe + '/user/subject'
}
