<template>
  <div>
    <sec-navbar></sec-navbar>
    <div class="materials">
      <div class="condition">
        <a-card>
          <p style="text-align:center;">全国到底有多少所985大学？一首歌带你全面了解......</p>
          <div class="video-div" style="margin-top: 0px;">
            <video controls autoplay id="video">
              <!-- 不知道怎么插入视频，按照下面的方式插入的话，vue会终止出去 -->
              <source src="@/assets/video/985.mp4" type="video/mp4">
              <!-- <source src="#" type="video/mp4"> -->
            </video>
          </div>
          <!-- <div id="box" class="box">
            <div id="play" class="play"></div>
            <div id="progress" class="progress">
              <div id="bar" class="bar"></div>
              <div id="control" class="control"></div>
            </div>
            <div id="sound" class="soundon"></div>
            <div id="volume" class="volume">
              <div id="volume-bar" class="volume-bar"></div>
              <div id="volume-control" class="volume-control"></div>
            </div>
            <div id="full" class="full"></div>
          </div> -->

        </a-card>
      </div>
    </div>
  </div>
</template>

<script>
// import myAxios from "@/utils/axios";
import secNavbar from './pubChildren/secNavbar.vue'

export default {
  components: { secNavbar },
  data() {
    return {
    }
  },
  mounted() {
  },
  methods: {
  }
}
</script>

<style scoped>
.materials {
  margin: 0 40px 0 40px;
}

.condition {
  margin-top: 30px;
  /* border: 1px solid #eceaea; */
}

.video1 {
  width: 100%;
  /*height: 85%;*/
}

.video-div {
  margin: 50px auto 5px;
  width: 80%;
  position: relative;
}

#video {
  object-fit: fill;
  width: 100%;
  height: 100%;
}

.box {
  margin: 0 auto;
  width: 600px;
  height: 40px;
  background-color: #ff0000;
  border-radius: 10px;
  box-shadow: 1px 1px 2px 2px #232;
  border: 1px solid #ff0000;
}

.play {
  float: left;
  width: 0;
  height: 0;
  border-left: 15px solid #fff;
  border-top: 12px solid transparent;
  border-bottom: 12px solid transparent;
  margin-top: 8px;
  margin-left: 10px;
  cursor: pointer;
}

.pause {
  width: 8px;
  height: 20px;
  border-left: 4px solid #fff;
  border-right: 4px solid #fff;
  float: left;
  cursor: pointer;
  margin-top: 10px;
  margin-left: 10px;
}

.progress {
  width: 400px;
  height: 8px;
  background-color: #fff;
  float: left;
  border-radius: 5px;
  border: 1px solid #ccc;
  margin-top: 16px;
  margin-left: 10px;
  box-shadow: 1px 1px 2px 2px #132;
  position: relative;
}

.bar {
  width: 0%;
  height: 100%;
  background-color: #ccc;
  position: absolute;
  display: inline-block;
  top: 0;
  left: 0;
  /* border: 1px solid #fff; */
  border-radius: 5px;
  /* box-shadow: 1px 1px 2px 2px #132; */
}

.control {
  width: 18px;
  height: 18px;
  background-color: #fff;
  border-radius: 100%;
  position: absolute;
  left: 0;
  top: -5px;
  box-shadow: 1px 1px 2px 2px #132;
}

.soundon {
  width: 10px;
  height: 8px;
  border-right: 15px solid #fff;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  float: left;
  margin-top: 8px;
  margin-left: 15px;
  cursor: pointer;
}

.soundoff {
  width: 10px;
  height: 8px;
  border-right: 15px solid #ccc;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  float: left;
  margin-top: 8px;
  margin-left: 15px;
  cursor: pointer;
}

.volume {
  width: 60px;
  height: 8px;
  background-color: #fff;
  float: left;
  border-radius: 5px;
  border: 1px solid #ccc;
  margin-top: 16px;
  margin-left: 10px;
  box-shadow: 1px 1px 2px 2px #132;
  position: relative;
}

.volume-bar {
  width: 30%;
  height: 100%;
  background-color: #ccc;
  position: absolute;
  display: inline-block;
  top: 0;
  left: 0;
  /* border: 1px solid #fff; */
  border-radius: 5px;
  /* box-shadow: 1px 1px 2px 2px #132; */
}

.volume-control {
  width: 15px;
  height: 15px;
  background-color: #fff;
  border-radius: 100%;
  position: absolute;
  left: 0;
  top: -3px;
  box-shadow: 1px 1px 2px 2px #132;
}

.full {
  width: 15px;
  height: 15px;
  border: 3px solid #fff;
  float: left;
  margin-top: 12px;
  margin-left: 15px;
  transition-property: all;
  transition-duration: 0.5s;
}

.full:hover {
  width: 20px;
  height: 20px;
  border: 3px solid #ccc;
  float: left;
  margin-top: 10px;
  margin-left: 12px;
}
</style>
