<template>
  <div>
    <sec-navbar></sec-navbar>
    <div class="materials">
      <div class="condition">
        <a-card style="width: 100%" title="调剂服务 >" :bodyStyle="{ padding: 0 }" :hoverable="true" :tab-list="tabList"
          :active-tab-key="key" @tabChange="(key) => onTabChange(key, 'key')">
          <span slot="schRegions" slot-scope="item">
            <a-icon type="global" />{{ item.tabName }}
          </span>
          <a slot="extra" href="#"><a-dropdown>
              <a class="ant-dropdown-link" @click="(e) => e.preventDefault()">
                其他 <a-icon type="down" />
              </a>
              <a-menu slot="overlay">
                <a-menu-item>
                  <a @click="routeTo(6)">成绩查询</a>
                </a-menu-item>
                <a-menu-item>
                  <a @click="routeTo(7)">经验交流</a>
                </a-menu-item>
              </a-menu>
            </a-dropdown></a>
          <el-calendar v-model="value"></el-calendar>

        </a-card>

        <el-result title="个人调剂意向" subTitle="（请考生用简洁的语言写清自己的分数及调剂意向，打 * 为必填。）"></el-result>
        <el-form ref="form" :model="form" label-width="80px" style="margin-left: 20px;width: 90%;">
          <el-form-item label="* 姓名">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="* 报考类型">
            <el-radio-group v-model="form.resource">
              <el-radio label="全日制"></el-radio>
              <el-radio label="非全日制"></el-radio>
            </el-radio-group>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;（报考类型也为调剂类型）
          </el-form-item>

          <el-form-item label="报考院校">
            <el-select v-model="form.region" placeholder="请选择活动区域">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="调剂时间">
            <el-col :span="11">
              <el-date-picker type="date" placeholder="选择日期" v-model="form.date1" style="width: 100%;"></el-date-picker>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-time-picker placeholder="选择时间" v-model="form.date2" style="width: 100%;"></el-time-picker>
            </el-col>
          </el-form-item>
          <el-form-item label="调剂意向">
            <el-input type="textarea" v-model="form.desc"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="onSubmit">立即创建</el-button>
            <el-button>取消</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
// import myAxios from "@/utils/axios";
import secNavbar from './pubChildren/secNavbar.vue'

export default {
  components: { secNavbar },
  data() {
    return {
      value: new Date(),
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      }
    }
  },
  mounted() { },
  methods: {
    // 卡片下拉栏路由
    routeTo(id) {
      if (id === 6) {
        this.$router.push('/score')
        this.$store.commit('ChangeNavId', id)
      } else if (id === 7) {
        this.$router.push('/post')
        this.$store.commit('ChangeNavId', id)
      } else if (id === 8) {
        this.$router.push('/adjustment')
        this.$store.commit('ChangeNavId', id)
      }
    },
    onSubmit() {

    }
  }
}
</script>

<style scoped>
.materials {
  margin: 0 40px 0 40px;
}

.condition {
  margin-top: 30px;
  /* border: 1px solid #eceaea; */
}

.materialsTable {
  margin-top: 30px;
  border: 1px solid #eceaea;
}
</style>
