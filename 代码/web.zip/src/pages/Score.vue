<!-- 参考的是https://www.eol.cn/e_ky/zt/common/cjcx/#xizang 考研查询网站-->
<template>
  <div>
    <sec-navbar></sec-navbar>
    <div class="materials">
      <div class="condition">
        <a-card style="width: 100%" title="成绩查询 >" :bodyStyle="{ padding: 0 }" :hoverable="true" id="scoreACard">
          <span slot="schRegions" slot-scope="item">
            <a-icon type="global" />{{ item.tabName }}
          </span>
          <a slot="extra" href="#"><a-dropdown>
              <a class="ant-dropdown-link" @click="(e) => e.preventDefault()">
                其他 <a-icon type="down" />
              </a>
              <a-menu slot="overlay">
                <a-menu-item>
                  <a @click="routeTo(7)">经验交流</a>
                </a-menu-item>
                <a-menu-item>
                  <a @click="routeTo(8)">调剂服务</a>
                </a-menu-item>
              </a-menu>
            </a-dropdown></a>
          <!-- <div class="scoreTable">
            <a-table :columns="columns" :data-source="scoreData">

            </a-table>
          </div> -->
          <br>
          <!-- 表格 -->
          <div class="diqubox" >
            <div class="diqu-head clearfix">
              <div class="qk1 fl">地区</div>
              <div class="qk2 fl">成绩查询时间</div>
              <div class="qk3 fl">成绩查询入口</div>
              <div class="qk4 fl">成绩查询方式</div>
            </div>
            <div class="diqu-dq">
              <div class="dq clearfix" id="henan">
                <div class="qk1 fl">北京</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.bjeea.cn/html/yk/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="sichuan">
                <div class="qk1 fl">天津</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"> <a href="http://www.zhaokao.net/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="guangxi">
                <div class="qk1 fl">河北</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://www.hebeea.edu.cn/html/yzyk/index.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="shandong">
                <div class="qk1 fl">山西</div>
                <div class="qk2 fl"> <a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://www.sxkszx.cn/news/yjsks/index.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="heilongjiang">
                <div class="qk1 fl">内蒙古</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.nm.zsks.cn/kszs/yjsks/">查分入口</a>
                </div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="jilin">
                <div class="qk1 fl">辽宁</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.lnzsks.com/listinfo/yjs_1.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="jiangsu">
                <div class="qk1 fl">黑龙江</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.lzk.hl.cn/ykpd/kyxx/">查分入口</a>
                </div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="guangdong">
                <div class="qk1 fl">上海</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://www.shmeea.edu.cn/page/05100/index.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="ningxia">
                <div class="qk1 fl">江苏</div>
                <div class="qk2 fl"><a href="https://kaoyan.eol.cn/jiangsu/yanzhao/202312/t20231227_2551485.shtml">
                    <font color="orange">2月底前</font>
                  </a></div>
                <div class="qk3 fl"><a href="https://www.jseea.cn/webfile/examination/graduateenrollment/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="jiangxi">
                <div class="qk1 fl">浙江</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a
                    href="https://www.zjzs.net/moban/index/2c9081f061d15b160161d165b2910012_tree.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="zhejiang">
                <div class="qk1 fl">安徽</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.ahzsks.cn/zhaokao/search.jsp?c=23">查分入口</a></div>
                <div class="qk4 fl"> <a
                    href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="hainan">
                <div class="qk1 fl">福建</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.eeafj.cn/ykyz/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="hubei">
                <div class="qk1 fl">江西</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl">
                  <a href="http://www.jxeea.cn/col/col26642/index.html">查分入口</a>
                </div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="hebei">
                <div class="qk1 fl">山东</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl">
                  <a href="http://www.sdzk.cn/NewsList.aspx?BCID=4">查分入口</a>
                </div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="yunnan">
                <div class="qk1 fl">河南</div>
                <div class="qk2 fl"><a href="">
                    <font color="orange">2月26日后</font>
                  </a></div>
                <div class="qk3 fl"><a href="http://www.heao.com.cn/main/html/yz/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="chongqing">
                <div class="qk1 fl">湖北</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://www.hbccks.cn/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="hunan">
                <div class="qk1 fl">湖南</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://jyt.hunan.gov.cn/sjyt/hnsjyksy/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="qinghai">
                <div class="qk1 fl">广东</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://eea.gd.gov.cn/yjsks/index.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="sanxi">
                <div class="qk1 fl">广西</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.gxeea.cn/yjsks/tzgg.htm">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="tianjin">
                <div class="qk1 fl">重庆</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl">
                  <a href="https://www.cqksy.cn/site/ShowClassArticleList.jsp?ClassID=287">查分入口</a>
                </div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="shanghai">
                <div class="qk1 fl">四川</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.sceea.cn/List/NewsList_39_1.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="shanxi">
                <div class="qk1 fl">贵州</div>
                <div class="qk2 fl"><a href="https://kaoyan.eol.cn/guizhou/yanzhao/202312/t20231227_2551488.shtml">
                    <font color="orange">2月26日后</font>
                  </a></div>
                <div class="qk3 fl"><a href="http://zsksy.guizhou.gov.cn/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="fujian">
                <div class="qk1 fl">云南</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl">
                  <a href="https://www.ynzs.cn/html/web/yjszs/index.html">查分入口</a>
                </div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="gansu">
                <div class="qk1 fl">西藏</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://edu.xizang.gov.cn/9/index.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="beijing">
                <div class="qk1 fl">陕西</div>
                <div class="qk2 fl"><a href="">暂未公布</a>
                </div>
                <div class="qk3 fl"><a href="https://www.sneea.cn/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="neimenggu">
                <div class="qk1 fl">甘肃</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.ganseea.cn/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="anhui">
                <div class="qk1 fl">青海</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://www.qhjyks.com/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>

              <div class="dq clearfix" id="liaoning">
                <div class="qk1 fl">宁夏</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="https://www.nxjyks.cn/contents/YJSKS/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="xinjiang">
                <div class="qk1 fl">新疆</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://www.xjzk.gov.cn/yjsks.html">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="guizhou">
                <div class="qk1 fl">吉林</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://www.jleea.com.cn/yjszs/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
              <div class="dq clearfix" id="xizang">
                <div class="qk1 fl">海南</div>
                <div class="qk2 fl"><a href="">暂未公布</a></div>
                <div class="qk3 fl"><a href="http://ea.hainan.gov.cn/ywdt/ptgkyjszsb/">查分入口</a></div>
                <div class="qk4 fl">
                  <a href="https://kaoyan.eol.cn/tiao_ji/chafen/202102/t20210222_2077797.shtml">研招网、招生考试院、高校研究生院</a>
                </div>
              </div>
            </div>
          </div>

          <!-- 分页条 -->
          <!-- <el-pagination background layout="total, sizes, prev, pager, next, jumper" style="text-align: center;"
            @size-change="handleSizeChange" @current-change="handleCurrentChange" :total="30"></el-pagination> -->
        </a-card>
      </div>
    </div>
  </div>
</template>

<script>
//   import myAxios from "@/utils/axios";
import secNavbar from './pubChildren/secNavbar.vue'
// // 筛选后成绩表格
// const columns = [
//   {
//     title: '地区',
//     dataIndex: 'province',
//     key: 'province'
//   },
//   {
//     title: '成绩查询时间',
//     dataIndex: 'time',
//     key: 'time'
//   },
//   {
//     title: '成绩查询入口',
//     key: 'in',
//     dataIndex: 'in'
//   },
//   {
//     title: '成绩查询方式',
//     key: 'way',
//     dataIndex: 'way'
//   }
// ]
// // 筛选后学校表格数据
// const scoreData = []

export default {
  components: { secNavbar },
  data() {
    return {}
  },
  mounted() { },
  methods: {
    // 卡片下拉栏路由
    routeTo(id) {
      if (id === 6) {
        this.$router.push('/score')
        this.$store.commit('ChangeNavId', id)
      } else if (id === 7) {
        this.$router.push('/post')
        this.$store.commit('ChangeNavId', id)
      } else if (id === 8) {
        this.$router.push('/adjustment')
        this.$store.commit('ChangeNavId', id)
      }
    }
  }
}
</script>

<style scoped>
.materials {
  margin: 0 40px 0 40px;
}

.condition {
  margin-top: 30px;
  /* border: 1px solid #eceaea; */
}

.scoreTable {
  margin-top: 30px;
  border: 1px solid #eceaea;
}

.diqubox {
  margin-top: 20px;
  margin-bottom: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction:column;
}

element.style {}

用户代理样式表 div {
  display: block;
}

body {
  font-family: "microsoft yahei";
  color: #333;
}

html,
body,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
p,
iframe,
dl,
dt,
dd,
ul,
ol,
li,
pre,
form,
button,
input,
textarea,
th,
td,
fieldset {
  margin: 0;
  padding: 0;
  list-style: none;
  text-decoration: none;
}

html {
  -webkit-text-size-adjust: none;
  -webkit-text-size-adjust: 100%;
}

.clearfix:after {
  content: ".";
  display: block;
  height: 0;
  clear: both;
  visibility: hidden;
}

.fl {
  float: left;
}

.qk1 {
  width: 145px;
  height: 40px;
  text-align: center;
  line-height: 40px;
  font-size: 16px;
  color: #fff;
  background: #1890ff;
  border-left: 1px solid #028789;
  box-sizing: border-box;
}

.qk2 {
  width: 320px;
  height: 40px;
  text-align: center;
  line-height: 40px;
  font-size: 16px;
  color: #fff;
  background: #1890ff;
  border-left: 1px solid #028789;
  box-sizing: border-box;
}

.qk3 {
  width: 290px;
  height: 40px;
  text-align: center;
  line-height: 40px;
  font-size: 16px;
  color: #fff;
  background: #1890ff;
  border-left: 1px solid #028789;
  box-sizing: border-box;
}

.qk4 {
  width: 445px;
  height: 40px;
  text-align: center;
  line-height: 40px;
  font-size: 16px;
  color: #fff;
  background: #1890ff;
  border-left: 1px solid #028789;
  border-right: 1px solid #028789;
  box-sizing: border-box;
}

.dq {
  .qk1,.qk2,.qk3,.qk4 {
    color: #434343;
    background: #fff;
    border-bottom: 1px solid #028789;
  }
}

</style>
