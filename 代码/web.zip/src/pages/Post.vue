<template>
  <div>
    <sec-navbar></sec-navbar>
    <div class="materials">
      <div class="condition">
        <a-card style="width: 100%" title="经验交流 >" :bodyStyle="{ padding: 0 }" :hoverable="true" :tab-list="tabList"
          :active-tab-key="key" @tabChange="(key) => onTabChange(key, 'key')">
          <a slot="extra"><a-button type="primary" @click="showModal" style="margin-right: 15px">帖子发布</a-button></a>
          <span slot="schRegions" slot-scope="item">
            <a-icon type="global" />{{ item.tabName }}
          </span>
          <a slot="extra" href="#"><a-dropdown>
              <a class="ant-dropdown-link" @click="(e) => e.preventDefault()">
                其他 <a-icon type="down" />
              </a>
              <a-menu slot="overlay">
                <a-menu-item>
                  <a @click="routeTo(6)">成绩查询</a>
                </a-menu-item>
                <a-menu-item>
                  <a @click="routeTo(8)">调剂服务</a>
                </a-menu-item>
              </a-menu>
            </a-dropdown></a>
          <el-input type="textarea" autosize placeholder="请输入帖子标题" style="margin-top: 15px; width: 96%; margin-left: 20px"
            v-model="textarea1">
          </el-input>
          <div style="margin: 20px 0"></div>
          <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 10 }" placeholder="请输入帖子内容"
            style="margin-bottom: 15px; width: 96%; margin-left: 20px" v-model="textarea2">
          </el-input>
        </a-card>
      </div>
      <br /><br />
      <a-card title="帖子搜索 >" style="width: 100%">
        <!-- 搜索框 -->
        <div style="width: 100%">
          <a-input-search placeholder="请输入帖子标题/内容关键词进行搜索" enter-button @search="onSearch" size="large"
            v-model="searchContent" />
        </div>
        <br />
        <!-- 多选框 -->
        <div>
          <div :style="{ borderBottom: '1px solid #E9E9E9' }">
            <a-checkbox :indeterminate="indeterminate" :checked="checkAll" @change="onCheckAllChange">
              全选
            </a-checkbox>
          </div>
          <br />

        </div>
      </a-card>
    </div>
  </div>
</template>

<script>
// import myAxios from "@/utils/axios";
import secNavbar from './pubChildren/secNavbar.vue'

export default {
  components: { secNavbar },
  data() {
    return {
      textarea1: '',
      textarea2: ''
    }
  },
  mounted() { },
  methods: {
    // 卡片下拉栏路由
    routeTo(id) {
      if (id === 6) {
        this.$router.push('/score')
        this.$store.commit('ChangeNavId', id)
      } else if (id === 7) {
        this.$router.push('/post')
        this.$store.commit('ChangeNavId', id)
      } else if (id === 8) {
        this.$router.push('/adjustment')
        this.$store.commit('ChangeNavId', id)
      }
    },
    showModal() {
      if (!this.$store.state.userInfo.token) {
        alert('请先登录再执行此操作!')
        this.$store.state.navbarId = 1
        this.$router.push('/')
        return
      }
      this.visible = true
    }
  }
}
</script>

<style scoped>
.materials {
  margin: 0 40px 0 40px;
}

.condition {
  margin-top: 30px;
  /* border: 1px solid #eceaea; */
}

/* .materialsTable {
    margin-top: 30px;
    border: 1px solid #eceaea;
  } */
</style>
